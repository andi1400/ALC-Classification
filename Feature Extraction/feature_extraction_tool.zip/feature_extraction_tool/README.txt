To start you need weka.jar , download from http://www.cs.waikato.ac.nz/~ml/weka/downloading.html, extract the download file and you can find the weka.jar in the extracted filer.

To run feature extractor:

1- Copy the CSV file to the Feature Extractor's directory
2- run extractor.sh "bash extractor.sh <csv file> <full path to weka.jar>"
3- run run_extractor.sh "bash run_extractor.sh <full path to weka.jar > <full path to the folder created by the previous script; with the same name as the csv file>"

You will see ".arff file created", and you can find it in the same directory
