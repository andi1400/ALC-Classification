import java.io.*;

import weka.core.Instances;
import weka.core.converters.TextDirectoryLoader;
import weka.filters.*;
import weka.filters.unsupervised.attribute.StringToWordVector;

public class TextToNum {
	public static void main(String[] args) throws Exception {
		String currDir = args[0];
		String[] fullPath = currDir.split("/");
		String fileName = fullPath[fullPath.length - 1];


		TextDirectoryLoader loader = new TextDirectoryLoader();
		loader.setDirectory(new File(currDir));
		Instances dataRaw = loader.getDataSet();

		StringToWordVector filter = new StringToWordVector();
		filter.setWordsToKeep(20000);

		filter.setInputFormat(dataRaw);
		Instances dataFiltered = filter.useFilter(dataRaw, filter);


		FileWriter fstream = new FileWriter(fileName + ".arff");
		BufferedWriter out = new BufferedWriter(fstream);
		out.write(dataFiltered.toString());
		out.close();
		System.out.println(fileName +".arff created");

	}
}
