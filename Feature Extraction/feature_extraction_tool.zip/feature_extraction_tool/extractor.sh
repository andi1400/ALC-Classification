#!/bin/bash


filename=$(basename "$1")
filename="${filename%.*}"
homedir=$(pwd)

OIFS="${IFS}"
NIFS=$'\n'

IFS="${NIFS}"
mkdir $filename && cd $filename

for i in $(cat "$homedir/$1" | cut -d, -f2 | sort -u);
do	
	mkdir $i && cd $i
	file=1
	

	for j in $(grep ",$i$" "$homedir/$1"| cut -d, -f1);
	do

		echo $j >> "$file.txt"
		(( file++ ))
	done
	cd ..
done
IFS="${OIFS}"

javac -cp $2:. "$homedir/TextToNum.java"

echo "$filename folder created"

