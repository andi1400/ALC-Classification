#!/bin/bash

java -Xmx200M -classpath $1:. TextToNum $2
